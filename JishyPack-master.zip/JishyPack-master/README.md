# JishyPack -- Faithful Edit
Jishy's somewhat custom resource pack for Minecraft 1.12!

This pack is currently only compatible with the 1.12 version of Minecraft, more versions coming soon!

## =======================================

# CREDITS:
THIS PACK IS NOT 100% CUSTOM MADE!!!!
ALL BLOCKS, AND MOST ITEMS, ARE FROM THE FAITHFUL 32X RESOURCE PACK!!! ALL CREDITS FOR THOSE GO TO THE CREATORS OF THE FAITHFUL 32X RESOURCE PACK!!

Other than the faithful stuff, this pack is made by Carter and Jishy.

## =======================================

# Current version of pack:

This pack is stull being made. Currently v1.12_0.3

## =======================================

# How to install:

Click the green "Clone or download" button. __Unzip the file__, and put the folder into your Minecraft resource pack folder. (It is very important that you remember to unzip the file)

![CloneOrDownload](/readmeimages/CloneOrDownload.png)

## =======================================

# Stuff in this pack:

  - Blocks and items from Faithful resource pack
  - *Smartphones (see below)
  - Custom Language (doesn't change much, made just for the fun of it)
  - Transparent items frames when placed
  - Custom menu textures
  - Custom creative inventory textures
  
*If you use Optifine, renaming the compass to the name of any select smartphones will change the texture to that phone. 
Phone currently in the pack (more coming in the future)
  - iPhone 6s
  - iPhone 8 Plus
  - Asus ROG Phone
  - Galaxy S8 Plus
  - Galaxy S10 Plus
  - Galaxy S10
  - Galaxy S2
  - Galaxy S3
  - Galaxy S4
  - Galaxy S8
  - iPhone 8
  - iPhone XS Max
  - Galaxy Note 9
  - OnePlus 7 Pro
  - Pixel 3a
  - Pixel 3 XL
  - Razer Phone 2
  - Razer Phone 1
  - Galaxy S6 Edge
  - Galaxy S7
  - Galaxy S10e
  - Galaxy S1
  - iPhone X
  
![phones](/readmeimages/phones.png)
*image does not show ALL of the phones added*


_there is currently 1 easter egg hidden inside the pack (requires optifine to see in game)_
